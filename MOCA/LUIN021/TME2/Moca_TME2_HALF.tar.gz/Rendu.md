Seuls l'exercice 1 est fait je souhaitais attendre ce week end afin de mieux faire les entrainement au tme solo dans de vrais conditions


#Exercice 1

*Question 1*
 La solution est maximale est 10.5. 
Avec 
x1 = 2.5 
x2 = 1.5
x3 = 0

Les contraintes 1 et 2 sont serrées avec 
c1 : 2.5 + 1.5 = 4
c2 : 2 * 2.5 + 3 * 0 = 5
Les variables x1 et x2 sont en Base et x3 est hors base.


*Question 2*

La solution duale associé est 
y1 = 2 
y2 = 0.5
y3 = 0

*Question 3*

Les variables en base et hors base sont identiques. 
La solution optimale a neanmoins augmenté de 10.5 à 11 et toutes les contraintes sont mainentenant serrés.
Avec 
x1 = 3
x2 = 1
x3 = 0

Et
c1 : 3 + 1 = 4
c2 : 2 * 3 + 3 * 0 = 6
c3 : 2 * 3 + 1 +  3 * 0 = 7

La solution duale associé est 
y1 = 1
y2 = 0
y3 = 1
avec une solution optimale de 11. Les variables y1 et y2 sont en base et y2 est hors base


*Question 4*

Les variables en base et hors base sont identiques. 
La solution optimale a neanmoins augmenté de 11 à 12 et toutes les contraintes sont mainentenant serrés.
Avec 
x1 = 2
x2 = 3
x3 = 0

Et
c1 : 2 + 3 = 5
c2 : 2 * 2 + 3 * 0 = 6
c3 : 2 * 2 + 3 +  3 * 0 = 7

La solution duale associé est est identique a la question precedente 

*Question 5*

5) cf exo1.5.lp


*Question 6*

Nous avons les mêmes données que le primal donc ce n'etait pas utile