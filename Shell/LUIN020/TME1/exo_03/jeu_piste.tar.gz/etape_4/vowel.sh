#!/bin/bash

str="$*"
vowels="$(echo "$str"|grep -oi [aieou])"
count="$(echo "$vowels"|wc -l)"

if [ "$count" -gt "3" ]; then
	echo "'$str'has $count vowels"
	cat $str
fi

