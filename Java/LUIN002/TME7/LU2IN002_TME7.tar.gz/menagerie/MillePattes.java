public class MillePattes extends AnimauxAPattes{

  public MillePattes(){
        super("MillePattes", 2);
    }

    public MillePattes(int age){
        super("MillePattes", 2, age);
    }

    public void crier(){
        System.out.println("dkrkrkkrrrss");
    }

}