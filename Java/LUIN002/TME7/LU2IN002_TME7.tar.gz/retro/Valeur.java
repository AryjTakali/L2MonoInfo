public class Valeur extends Expression{
    private double v;

    public Valeur(double v1){
        v = v1;
    }
    
    public Valeur(Valeur v1){
        v = v1.getVal();
    }

    public Valeur getVal(){
        return v;
    }
}