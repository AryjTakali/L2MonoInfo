#!/bin/bash

for f in *;do 
	sh vowel.sh $f;
done
