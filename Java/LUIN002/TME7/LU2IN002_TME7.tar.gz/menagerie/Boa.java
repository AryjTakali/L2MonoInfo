public class Boa extends AnimauxSansPattes{
    
    public Boa(){
        super("Boa");
    }

    public Boa(int age){
        super("Boa", age);
    }

    public void crier(){
        System.out.println("PssssssSSSsss");
    }

}