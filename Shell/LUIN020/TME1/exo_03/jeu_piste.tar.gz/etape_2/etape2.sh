#!/bin/bash

for f in *e;do 
	sh nbChar.sh $f;
done
