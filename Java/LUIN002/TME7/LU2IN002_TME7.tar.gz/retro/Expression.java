public abstract class Expression{
    private Valeur v;

    public abstract Valeur getVal();

}