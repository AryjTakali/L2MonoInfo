#!/bin/bash

str="$*"
letter="$(echo "$str"|grep -oi [a-z])"
count="$(echo "$letter"|wc -l)"

if [ "$count" -eq "8" ]; then
	echo "'$str'has $count letters"
	cat $str
fi
