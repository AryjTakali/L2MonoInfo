#!/bin/bash

for f in *; do
	count=0;
	for (i in f);
	do
	case $i in
		[aeiou]
		count=$(($count + 1))
	done
	if var>=4;
	cat f;
done
