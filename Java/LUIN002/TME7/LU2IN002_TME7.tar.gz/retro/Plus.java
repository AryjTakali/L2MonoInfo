public class Plus extends Operation{

  public Plus(Valeur v1, Valeur v2){
        super(v1, v2);
    }

    public Valeur getVal(){
        return v1.getVal() + v1.getVal();
    }
}