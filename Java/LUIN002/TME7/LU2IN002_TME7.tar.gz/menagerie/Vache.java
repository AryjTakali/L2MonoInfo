public class Vache extends AnimauxAPattes{

  public Vache(){
        super("Vache", 4);
    }

    public Vache(int age){
        super("Vache", 4, age);
    }

    public void crier(){
        System.out.println("dkrkrkkrrrss");
    }

}